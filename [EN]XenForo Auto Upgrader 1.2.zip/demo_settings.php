<?php
/*
-----------------------------------------------------------------------------------------------------------------
START OF DEMO SCRIPT CODE. THIS CODE IS ONLY USED BY DEMO SCRIPT. YOU DO NOT NEED TO ADD THIS CODE TO YOUR SCRIPT.
-----------------------------------------------------------------------------------------------------------------
*/

//Set demo script name
$DEMO_PRODUCT_NAME="XenForo Nulled Auto Upgrader";

//Set original product name
$ORIGINAL_PRODUCT_NAME="XenForo Auto Upgrader";

//Set original product url
$ORIGINAL_PRODUCT_URL="https://xfcheat.com";

//Set default date to prevent errors from being displayed if user's server requires default date to be set
date_default_timezone_set(date_default_timezone_get());

/*
-----------------------------------------------------------------------------------------------------------------
END OF DEMO SCRIPT CODE. THIS CODE IS ONLY USED BY DEMO SCRIPT. YOU DO NOT NEED TO ADD THIS CODE TO YOUR SCRIPT.
-----------------------------------------------------------------------------------------------------------------
*/

/*
-----------------------------------------------------------------------------------------------------------------
START OF CODE TO INCLUDE REQUIRED FILES. YOU SHOULD ADD THIS CODE TO YOUR SCRIPT.
-----------------------------------------------------------------------------------------------------------------
*/

//Load file with PHP Auto Update Script settings
require_once("SCRIPT/aus_core_configuration.php");

//Load file with PHP Auto Update Script functions
require_once("SCRIPT/aus_core_functions.php");

/*
-----------------------------------------------------------------------------------------------------------------
END OF CODE TO INCLUDE REQUIRED FILES. YOU SHOULD ADD THIS CODE TO YOUR SCRIPT.
-----------------------------------------------------------------------------------------------------------------
*/
