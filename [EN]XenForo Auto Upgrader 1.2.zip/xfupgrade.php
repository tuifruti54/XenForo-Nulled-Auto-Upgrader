<?php
/*
-----------------------------------------------------------------------------------------------------------------
START OF DEMO SCRIPT CODE. THIS CODE IS ONLY USED BY DEMO SCRIPT. YOU DO NOT NEED TO ADD THIS CODE TO YOUR SCRIPT.
-----------------------------------------------------------------------------------------------------------------
*/

//Load settings file which is responsible for including files required by PHP Auto Update Script
require_once("demo_settings.php");


  $url = $_SERVER['SCRIPT_URI'];
  $url = str_replace('/xfupgrade.php','',$url);
  
  $rootDir = $_SERVER['DOCUMENT_ROOT'];
  $xfinstallation = $rootDir . '/src/XF.php';


  if (file_exists($xfinstallation)) {
    require($rootDir . '/src/XF.php');
    $version_xenforo = XF::$version;
      $xenforo = "Your actual XenForo Version: ".$version_xenforo;
  } else {
      $xenforo = "Your actual XenForo Version: <font color=red>XenForo is not installed on your server !</font>";
  }

//Set basic variables such as page title, default message, etc.
$demo_page_title="Download Files";
$demo_page_message="<div align ='center'>Welcome to XenForo Auto Updater by XFCheat.com - You can here choose if you want to install XenForo or just update it!
</br>
</br>
</br>
When Upgrade is mark as complet here go to : <a href='".$url."/install'><font color='red'><b>".$url."/install</b></font></a> and complete your XenForo Upgrade :)</br>
</br>
</br>
".
  $xenforo.
"
<br />
<br />
All Work by <a href ='https://xfcheat.com'>XFCheat Community !</a></div>
";
$demo_page_class="alert alert-primary";

//Get all variables submitted by user
if (!empty($_POST) && is_array($_POST))
    {
    extract(array_map("trim", $_POST), EXTR_SKIP); //automatically make a variable from each argument submitted by user (don't overwrite existing variables)
    }

//Custom file titles used for demo notifications only
$file_types_title_array=array("version_install_file"=>"Archive with installation files", "version_upgrade_file"=>"Archive with upgrade files", "version_install_query"=>"Archive with installation MySQL query", "version_upgrade_query"=>"Archive with upgrade MySQL query");

/*
-----------------------------------------------------------------------------------------------------------------
END OF DEMO SCRIPT CODE. THIS CODE IS ONLY USED BY DEMO SCRIPT. YOU DO NOT NEED TO ADD THIS CODE TO YOUR SCRIPT.
-----------------------------------------------------------------------------------------------------------------
*/

/*
-----------------------------------------------------------------------------------------------------------------
START OF PHP AUTO UPDATE SCRIPT CODE REQUIRED TO DOWNLOAD FILES. YOU SHOULD ADD THIS CODE TO YOUR SCRIPT.
-----------------------------------------------------------------------------------------------------------------
*/

if (isset($submit_ok))
    {
    //Function can be provided with file type and version number as arguments (only when specific archive of old version is needed).
    //Function will return array with 'notification_case', 'notification_text' and 'notification_data' keys, where 'notification_case' contains action status, 'notification_text' contains action summary, and 'notification_data' contains additional data (if any).
    //Function will also download specified archive and extract files in script's root directory. Optionally, it will automatically delete downloaded archive after extracting it.
    $download_notifications_array=ausDownloadFile($file_type, $version_number);

    if ($download_notifications_array['notification_case']=="notification_operation_ok") //'notification_operation_ok' case returned - operation succeeded
        {
        $demo_page_message=$file_types_title_array[$file_type]." for ".$download_notifications_array['notification_data']['product_title']." version ".$download_notifications_array['notification_data']['version_number']." downloaded and extracted successfully.";
        $demo_page_class="alert alert-success";
        }
    else //Other case returned - operation failed
        {
        $demo_page_message=$file_types_title_array[$file_type]." could not be downloaded because of this reason: ".$download_notifications_array['notification_text'];
        $demo_page_class="alert alert-danger";
        }
    }

/*
-----------------------------------------------------------------------------------------------------------------
END OF PHP AUTO UPDATE SCRIPT CODE REQUIRED TO DOWNLOAD FILES. YOU SHOULD ADD THIS CODE TO YOUR SCRIPT.
-----------------------------------------------------------------------------------------------------------------
*/
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title><?php echo "$demo_page_title - $DEMO_PRODUCT_NAME - Updated by $ORIGINAL_PRODUCT_NAME"; ?></title>
    <link rel="stylesheet" href="css/fontawesome/css/all.min.css">
    <link href="css/style.min.css" rel="stylesheet">
  </head>
  <body class="app header-fixed sidebar-fixed aside-menu-fixed sidebar-lg-show">
    <header class="app-header navbar">
      <button class="navbar-toggler sidebar-toggler d-lg-none mr-auto" type="button" data-toggle="sidebar-show">
        <span class="navbar-toggler-icon"></span>
      </button>
      <a class="navbar-brand" href="https://xfcheat.com" title="phpmillion" target="_blank"><strong>XFCheat Auto Upgrader</strong></a>
    </header>
    <div class="app-body">
      <div class="sidebar">
        <nav class="sidebar-nav">
          <ul class="nav">
            <li class="nav-title"><?php echo $DEMO_PRODUCT_NAME; ?></li>
            <li class="nav-item"><a class="nav-link" href="get_version.php"><i class="fas fa-info"></i> &nbsp; Check Update</a></li>
            <li class="nav-item"><a class="nav-link" href="xfupgrade.php"><i class="fas fa-cloud-download-alt"></i> &nbsp; Download Files</a></li>
          </ul>
        </nav>
      </div>
      <main class="main">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo $ORIGINAL_PRODUCT_URL; ?>"><?php echo $ORIGINAL_PRODUCT_NAME; ?></a></li>
          <li class="breadcrumb-item active"><?php echo $demo_page_title; ?></li>
        </ol>
        <div class="container-fluid">
          <div class="animated fadeIn">
            <div class="card">
              <div class="card-header"><i class="fas fa-code"></i><?php echo $DEMO_PRODUCT_NAME; ?></div>
              <div class="card-body">
                <div class="<?php echo $demo_page_class; ?>" role="alert"><strong><?php echo $demo_page_message; ?></strong></div>
                <?php if (!isset($submit_ok)) { ?>
                <?php } ?>
              </div>
            </div>
            <div class="card">
              <form action="<?php echo basename(__FILE__); ?>" method="post">
              <div class="card-header"><i class="fas fa-cloud-download-alt"></i><?php echo $demo_page_title; ?></div>
              <?php if ($demo_page_class!="alert alert-success") { ?>
              <div class="card-body">
                <div class="row">
                  <div class="col-sm-4">
                    <div class="form-group">
                      <label for="name">XenForo Update/Installation</label>
                      <select name="file_type" class="form-control"><option value="version_install_file">Install XenForo Nulled</option><option value="version_upgrade_file" <?php if (!empty($file_type) && $file_type=="version_upgrade_file") {echo " selected";} ?>>Update XenForo Nulled</option></select>
                    </div>
                  </div>
                </div>
              </div>
              <div class="card-footer">

<style type="text/css" media="screen">
.button, a.button {
    display: inline-block;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    text-decoration: none;
    cursor: pointer;
    border: 1px solid transparent;
    white-space: nowrap;
    -webkit-transition: background-color 0.25s ease;
    transition: background-color 0.25s ease;
    font-size: 13px;
    border-radius: 4px;
    padding-top: 5px;
    padding-right: 10px;
    padding-bottom: 5px;
    padding-left: 10px;
    text-align: center;
    color: #edf6fd;
    background: #2577b1;
    border-color: #2985c6 #21699c #21699c #2985c6;
}
</style>


                <div align="center"><button class="button" name="submit_ok"><i class="fas fa-check"></i> Start Installation/Update !</button></div>
              </div>
              <?php } ?>
              <?php if ($demo_page_class=="alert alert-success") { ?>
              <div class="card-body">
                <p class="h4">Downloading and Extracting <?php echo ucwords($file_types_title_array[$file_type]); ?>... Completed!</p>
                <div class="progress">
                  <div class="progress-bar progress-bar-striped bg-success" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width:100%"></div>
                </div>
                <br><br>
                <div class="jumbotron">
                  <p class="lead">For your convenience, full unprocessed data (returned by <?php echo $ORIGINAL_PRODUCT_NAME; ?> server) is displayed below:</p>
                  <p class="lead"><pre><?php print_r($download_notifications_array['notification_data']); ?></pre></p>
                </div>
              </div>
              <?php } ?>
              </form>
            </div>
          </div>
        </div>
      </main>
    </div>
    <footer class="app-footer">
      <div>
        <a href="https://xfcheat.com">XFCheat Auto Upgrader</a> <span>&copy; <?php echo date("Y"); ?></span>
      </div>
      <div class="ml-auto">
        <span>Updated by</span> <a href="<?php echo $ORIGINAL_PRODUCT_URL; ?>"><?php echo $ORIGINAL_PRODUCT_NAME; ?></a>
      </div>
    </footer>
    <script src="js/jquery/jquery.min.js"></script>
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <script src="js/coreui/coreui.min.js"></script>
  </body>
</html>
